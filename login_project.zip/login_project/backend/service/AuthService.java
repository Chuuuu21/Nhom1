package com.example.demo.service;

import com.example.demo.model.Dangky;
import com.example.demo.model.Dangnhap;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Service
public class AuthService {

    private final ObjectMapper objectMapper = new ObjectMapper();

    private final ResourceLoader resourceLoader;

    private File userFile;

    public AuthService(ResourceLoader resourceLoader,
                       @Value("classpath:backend/resources/users.json") Resource resource) throws IOException {
        this.resourceLoader = resourceLoader;
        this.userFile = resource.getFile();
    }

    // Đảm bảo file tồn tại
    @PostConstruct
    public void init() throws IOException {
        if (!userFile.exists()) {
            userFile.getParentFile().mkdirs();
            userFile.createNewFile();
            writeUsers(new ArrayList<>());
        }
    }

    // Đăng ký
    public String register(Dangky dangky) {
        List<Dangky> users = readUsers();
        for (Dangky user : users) {
            if (user.getUsername().equals(dangky.getUsername())) {
                return "Username đã tồn tại!";
            }
        }
        users.add(dangky);
        writeUsers(users);
        return "Đăng ký thành công!";
    }

    // Đăng nhập
    public String login(Dangnhap dangnhap) {
        List<Dangky> users = readUsers();
        for (Dangky user : users) {
            if (user.getUsername().equals(dangnhap.getUsername()) &&
                user.getPassword().equals(dangnhap.getPassword())) {
                return "Đăng nhập thành công!";
            }
        }
        return "Sai username hoặc password!";
    }

    // Đọc file JSON
    private List<Dangky> readUsers() {
        try {
            if (!userFile.exists()) {
                return new ArrayList<>();
            }
            return objectMapper.readValue(userFile, new TypeReference<List<Dangky>>() {});
        } catch (IOException e) {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }

    // Ghi file JSON
    private void writeUsers(List<Dangky> users) {
        try {
            objectMapper.writerWithDefaultPrettyPrinter().writeValue(userFile, users);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package com.example.demo.controller;

import com.example.demo.model.Dangky;
import com.example.demo.model.Dangnhap;
import com.example.demo.service.AuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/auth")
@CrossOrigin(origins = "*") // Cho phép CORS toàn cầu, cân nhắc chỉnh lại domain cụ thể
public class AuthController {

    @Autowired
    private AuthService authService;

    @PostMapping(value = "/register", produces = "application/json")
    public ResponseEntity<Map<String, String>> register(@RequestBody Dangky dangky) {
        String result = authService.register(dangky);

        Map<String, String> response = new HashMap<>();
        response.put("message", result);

        if (result.contains("thành công")) {
            return ResponseEntity.ok(response);
        } else {
            return ResponseEntity.badRequest().body(response);
        }
    }

    @PostMapping(value = "/login", produces = "application/json")
    public ResponseEntity<Map<String, String>> login(@RequestBody Dangnhap dangnhap) {
        String result = authService.login(dangnhap);

        Map<String, String> response = new HashMap<>();
        response.put("message", result);

        if (result.contains("thành công")) {
            return ResponseEntity.ok(response);
        } else {
            return ResponseEntity.status(401).body(response);
        }
    }
}

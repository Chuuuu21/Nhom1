document.addEventListener('DOMContentLoaded', function () {
  const tableBody = document.querySelector('table tbody');
  const searchInput = document.querySelector('input[type="text"]');
  const searchBtn = document.querySelector('.search-upload button:nth-of-type(1)');
  const uploadBtn = document.querySelector('.upload-btn');
  const deleteBtn = document.querySelector('.delete-btn');
  const downloadBtn = document.querySelector('.download-btn');

  let selectedId = null;

  function loadDocuments(search = '') {
    fetch(`http://localhost:4000/api/documents?search=${encodeURIComponent(search)}`)
      .then(res => res.json())
      .then(data => {
        tableBody.innerHTML = '';
        data.forEach(doc => {
          const row = document.createElement('tr');
          row.innerHTML = `
            <td>${doc.name}</td>
            <td>${doc.type}</td>
            <td>${doc.uploader}</td>
            <td>${doc.uploadDate}</td>
          `;
          row.addEventListener('click', () => {
            selectedId = doc.id;
            document.querySelectorAll('tbody tr').forEach(r => r.classList.remove('selected'));
            row.classList.add('selected');
          });
          tableBody.appendChild(row);
        });
      })
      .catch(err => {
        alert('Lỗi khi tải tài liệu.');
        console.error(err);
      });
  }

  searchBtn.addEventListener('click', () => {
    loadDocuments(searchInput.value);
  });

  uploadBtn.addEventListener('click', () => {
    const name = prompt('Document name?');
    if (!name) return alert('Bạn cần nhập tên tài liệu.');

    const uploader = 'Ho Ngoc Binh';
    const fileInput = document.createElement('input');
    fileInput.type = 'file';
    fileInput.accept = '.pdf';

    fileInput.addEventListener('change', () => {
      const file = fileInput.files[0];
      if (!file) return;

      const formData = new FormData();
      formData.append('file', file);
      formData.append('name', name);
      formData.append('uploader', uploader);

      fetch('http://localhost:4000/api/documents/upload', {
        method: 'POST',
        body: formData
      })
        .then(res => res.json())
        .then(res => {
          if (res.message) alert(res.message);
          loadDocuments();
        })
        .catch(err => {
          alert('Tải tài liệu thất bại.');
          console.error(err);
        });
    });

    fileInput.click();
  });

  deleteBtn.addEventListener('click', () => {
    if (!selectedId) return alert('Select a document to delete');

    if (!confirm('Bạn có chắc chắn muốn xoá tài liệu này không?')) return;

    fetch(`http://localhost:4000/api/documents/${selectedId}`, {
      method: 'DELETE'
    })
      .then(res => res.json())
      .then(res => {
        alert(res.message);
        selectedId = null;
        loadDocuments();
      })
      .catch(err => {
        alert('Xoá thất bại.');
        console.error(err);
      });
  });

  downloadBtn.addEventListener('click', () => {
    if (!selectedId) return alert('Select a document to download');
    window.open(`http://localhost:4000/api/documents/download/${selectedId}`, '_blank');
  });

  // Load initial list
  loadDocuments();
});

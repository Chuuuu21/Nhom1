const express = require('express');
const multer = require('multer');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
const { v4: uuidv4 } = require('uuid');

const app = express();
const PORT = 4000;
const BASE_DIR = path.resolve(__dirname);

app.use(cors());
app.use(express.json());

// Serve static frontend files
app.use(express.static(path.join(BASE_DIR, 'frontend')));
app.get('/', (req, res) => {
  res.sendFile(path.join(BASE_DIR, 'frontend', 'quanlitailieu.html'));
});

// Serve uploaded files
app.use('/uploads', express.static(path.join(BASE_DIR, 'uploads')));

const DATA_FILE = path.join(BASE_DIR, 'data.json');
function readData() {
  if (!fs.existsSync(DATA_FILE)) return [];
  return JSON.parse(fs.readFileSync(DATA_FILE, 'utf-8'));
}
function writeData(data) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
}

const storage = multer.diskStorage({
  destination: (_, __, cb) => cb(null, path.join(BASE_DIR, 'uploads')),
  filename: (_, file, cb) => cb(null, Date.now() + '-' + file.originalname)
});
const upload = multer({ storage });

// API
app.get('/api/documents', (req, res) => {
  const { search } = req.query;
  let docs = readData();
  if (search) {
    docs = docs.filter(d => d.name.toLowerCase().includes(search.toLowerCase()));
  }
  res.json(docs);
});

app.post('/api/documents/upload', upload.single('file'), (req, res) => {
  const { name, uploader } = req.body;
  const file = req.file;
  if (!file || !name || !uploader) {
    return res.status(400).json({ message: 'Missing file or required fields.' });
  }
  const newDoc = {
    id: uuidv4(),
    name,
    type: path.extname(file.originalname).replace('.', '').toUpperCase(),
    uploader,
    uploadDate: new Date().toISOString().split('T')[0],
    filePath: `/uploads/${file.filename}`
  };
  const docs = readData();
  docs.push(newDoc);
  writeData(docs);
  res.json({ message: 'Upload successful.', doc: newDoc });
});

app.get('/api/documents/download/:id', (req, res) => {
  const doc = readData().find(d => d.id === req.params.id);
  if (!doc) return res.status(404).json({ message: 'Document not found.' });
  res.download(path.join(BASE_DIR, doc.filePath));
});

app.delete('/api/documents/:id', (req, res) => {
  let docs = readData();
  const doc = docs.find(d => d.id === req.params.id);
  if (!doc) return res.status(404).json({ message: 'Document not found.' });
  const fullPath = path.join(BASE_DIR, doc.filePath);
  if (fs.existsSync(fullPath)) fs.unlinkSync(fullPath);
  docs = docs.filter(d => d.id !== req.params.id);
  writeData(docs);
  res.json({ message: 'Document deleted successfully.' });
});

app.listen(PORT, () => console.log(`✅ Server running at http://localhost:${PORT}`));
